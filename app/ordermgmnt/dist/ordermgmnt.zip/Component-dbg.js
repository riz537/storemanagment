sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("com.demo.ordermgmnt.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);